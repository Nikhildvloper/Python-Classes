print("a")
print("b")
print("c", end="")
print("d", end=""), 