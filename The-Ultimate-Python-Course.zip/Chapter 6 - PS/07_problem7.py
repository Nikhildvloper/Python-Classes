post = input("Enter the post: ")



if("harry" in post.lower()):
    print("This post is talking about harry")

else:
    print("This post is not talking about harry")