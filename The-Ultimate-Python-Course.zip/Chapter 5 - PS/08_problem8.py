# Nothing will happen. The values can be same
