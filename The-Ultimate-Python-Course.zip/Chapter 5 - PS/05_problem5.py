s = {}
print(type(s))