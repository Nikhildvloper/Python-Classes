table = [str(7*i) for i in range(1, 11)]

s = "\n".join(table)
print(s)