from typing import List, Union, Tuple 

n : int = 5

name: str = "Harry"


def  sum(a: int, b: int) -> int:
    return a+b

