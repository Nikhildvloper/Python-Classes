a = int(input("Enter your number: ")) 


print("The square of the number is", a**2)
print("The square of the number is", a*a)
# print("The square of the number is", a^2) # Incorrect for finding square of a number in Python