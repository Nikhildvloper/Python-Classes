a = 'Harry is a good boy\nbut not a bad \'boy\''


print(a)