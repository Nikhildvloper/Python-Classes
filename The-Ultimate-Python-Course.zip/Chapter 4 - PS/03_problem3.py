a = (34, 234, "Harry")

a[2] = "Larry"