name = input("Enter your name: ")

print(f"Good Afternoon, {name} ") 